<template>
  <q-table :rows="table.rows" :columns="table.columns">

  </q-table>
</template>
<script>
</script>
