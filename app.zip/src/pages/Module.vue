<template>
  <q-page class="q-pa-md">
    <div class="row">
      <div class="col">
        {{ moduleName }} - {{ mode }}
        {{ $route.params }}
      </div>
      <div class="col">


      </div>
    </div>


  </q-page>
</template>
<script>
export default {
  name: 'customer',
  props: ['moduleName', 'mode'],
  data () {
    return {
      formData: {},
      table: {
        rows: [],
        columns: [
          { label: 'Name', field: 'name' },
          { label: 'DoB', field: 'dob' },
          { label: 'Contact Number', field: 'contact_number' },
        ]
      }
    }
  },
  methods: {
    addToTable () {
      this.table.rows.push(JSON.parse(JSON.stringify(this.formData)))
      this.formData = {}
    }
  }
}

</script>
